import React from 'react';
import './Home.css';
import Product from './Product';




function Home() {
    return (
        <div className="home">
            <div className="home--container">
            <img className="home--image" src="https://m.media-amazon.com/images/I/61JoMEvINFL._SX3000_.jpg" alt=""/>
            
            <div className="home--row">
                <Product
                id="01"
                
                price={999}
                image="https://m.media-amazon.com/images/I/41LpEJk1GlS.jpg" 
                title="MILLIONSTORE Men's Joggers"
                
                />
                 <Product
                id="02"
                
                price={325}
                image="https://m.media-amazon.com/images/I/71mcY2boNVL._UL1500_.jpg" 
                title="ALAMOS Combo Pack of 2 edixo Cap"
                
                />
                 <Product
                id="03"
                
                price={6999}
                image="https://m.media-amazon.com/images/I/51YVqK4FLFL._UL1000_.jpg" 
                title=" Nike Men's Jordan Jumpman 2021 Pf Basketball Shoe"
                
                />
                
              
            </div>
            <div className="home--row">
            
                 <Product
                id="02"
                
                price={499}
                image="https://m.media-amazon.com/images/I/51BjQvMdyjL.jpg" 
                title="EPC Games - N-F-S Carbon"
                
                />
                
                 <Product
                id="02"
                
                price={799}
                image="https://m.media-amazon.com/images/I/51dkyyxHSYL.jpg" 
                title="The Witcher 3"
                
                />
           
            </div>
            <div className="home--row">
            <Product
                id="02"
                
                price={1999}
                image="https://m.media-amazon.com/images/I/71ar2Uq1JvL._UL1500_.jpg" 
                title="THE CLOWNFISH 15.6 Inches Travel Outdoor"
                
                />
     
            </div>
        
            </div>  
        </div>
    )
}

export default Home
