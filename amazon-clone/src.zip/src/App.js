import React from 'react';
import './App.css';

import Header from './Header';
import Navbar from './Navbar';
import Home from './Home';

function App() {
  return (
    <div className="App">
     
      <Header/>
     <Navbar/>
      <Home/>
      
      </div>
  );
}

export default App;
