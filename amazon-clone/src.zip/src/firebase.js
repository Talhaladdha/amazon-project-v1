const firebaseConfig = {
    apiKey: "AIzaSyDdTCVVfY2RHx1X_sAnEOYDjYXHYMGK7Lc",
    authDomain: "project-v1-1e163.firebaseapp.com",
    projectId: "project-v1-1e163",
    storageBucket: "project-v1-1e163.appspot.com",
    messagingSenderId: "474355555425",
    appId: "1:474355555425:web:3efded7f365602c9b55e20"
  };